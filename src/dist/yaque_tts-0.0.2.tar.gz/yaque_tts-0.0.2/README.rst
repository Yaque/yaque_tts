说明一下
  Definition of "说明一下". 他需要下载一个声源包，具体请上homepage
